const GAME_WIDTH = 1280;
const GAME_HEIGHT = 720;

let scene;
let scenep;
let selectedTile;
let muteAll = false;
let mc = false;
let sc = false;
